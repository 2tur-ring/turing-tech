from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)
from flask import send_from_directory

@app.route("/")
def home():
    return send_from_directory(".", "index.html")


@app.route("/search")
def search():
    q = request.args.get("q", "")
    conn = sqlite3.connect("eugotube.db")
    cursor = conn.cursor()
    cursor.execute("""
        SELECT * FROM videos
        WHERE titulo LIKE ? OR descricao LIKE ?
    """, ('%' + q + '%', '%' + q + '%'))
    results = cursor.fetchall()
    conn.close()

    videos = []
    for r in results:
        videos.append({
            "id": r[0],
            "plataforma": r[1],
            "titulo": r[2],
            "descricao": r[3],
            "url": r[4],
            "thumbnail": r[5],
            "duracao": r[6]
        })

    return jsonify(videos)

if __name__ == "__main__":
    app.run(port=5000)
