
import requests
from db import insert_video

ACCESS_TOKEN = "dc3840a68c0fb3828d04292352ff56ea"
headers = {"Authorization": f"Bearer {ACCESS_TOKEN}"}

url = "https://api.vimeo.com/videos?query=python&per_page=5"
response = requests.get(url, headers=headers).json()

for video in response.get("data", []):
    video_json = {
        "plataforma": "vimeo",
        "id": video["uri"].split("/")[-1],
        "titulo": video["name"],
        "descricao": video.get("description", ""),
        "url": video["link"],
        "thumbnail": video["pictures"]["sizes"][0]["link"],
        "duracao": video["duration"],
        "tags": video.get("tags", [])
    }
    insert_video(video_json)   # salva no banco
