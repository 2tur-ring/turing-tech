from googleapiclient.discovery import build
from db import insert_video   # importa função para salvar no banco

API_KEY = "AIzaSyCUNCVvemfHyZPi50vgXAlWYWYOrp0DGzI"
youtube = build("youtube", "v3", developerKey=API_KEY)

request = youtube.videos().list(
    part="snippet",
    chart="mostPopular",
    maxResults=5,
    regionCode="BR"
)
response = request.execute()

for item in response["items"]:
    video = {
        "plataforma": "youtube",
        "id": item["id"],
        "titulo": item["snippet"]["title"],
        "descricao": item["snippet"]["description"],
        "url": f"https://youtube.com/watch?v={item['id']}",
        "thumbnail": item["snippet"]["thumbnails"]["default"]["url"],
        "duracao": 0,
        "tags": item["snippet"].get("tags", [])
    }
    insert_video(video)   # salva no banco
