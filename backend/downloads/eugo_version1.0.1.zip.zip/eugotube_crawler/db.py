# db.py
import sqlite3

# Cria (ou conecta) ao banco de dados SQLite
conn = sqlite3.connect("videos.db")
cursor = conn.cursor()

# Cria a tabela se não existir
cursor.execute("""
CREATE TABLE IF NOT EXISTS videos (
    id TEXT PRIMARY KEY,
    plataforma TEXT,
    titulo TEXT,
    descricao TEXT,
    url TEXT,
    thumbnail TEXT,
    duracao INTEGER,
    tags TEXT
)
""")
conn.commit()

def insert_video(video: dict):
    """
    Insere um vídeo no banco de dados.
    O parâmetro 'video' deve ser um dicionário com as chaves:
    plataforma, id, titulo, descricao, url, thumbnail, duracao, tags
    """
    cursor.execute("""
    INSERT OR REPLACE INTO videos (id, plataforma, titulo, descricao, url, thumbnail, duracao, tags)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        video["id"],
        video["plataforma"],
        video["titulo"],
        video["descricao"],
        video["url"],
        video["thumbnail"],
        video["duracao"],
        ",".join(video["tags"]) if isinstance(video["tags"], list) else video["tags"]
    ))
    conn.commit()

def get_all_videos():
    """
    Retorna todos os vídeos armazenados no banco.
    """
    cursor.execute("SELECT * FROM videos")
    return cursor.fetchall()

if __name__ == "__main__":
    # Teste simples
    print("=== Vídeos no banco ===")
    for v in get_all_videos():
        print(v)

import sqlite3

def init_db():
    conn = sqlite3.connect("eugotube.db")
    cursor = conn.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS videos (
        id TEXT PRIMARY KEY,
        plataforma TEXT,
        titulo TEXT,
        descricao TEXT,
        url TEXT,
        thumbnail TEXT,
        duracao INTEGER
    )
    """)
    conn.commit()
    conn.close()

def insert_video(video):
    conn = sqlite3.connect("eugotube.db")
    cursor = conn.cursor()
    cursor.execute("""
    INSERT OR REPLACE INTO videos VALUES (:id, :plataforma, :titulo, :descricao, :url, :thumbnail, :duracao)
    """, video)
    conn.commit()
    conn.close()
